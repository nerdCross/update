# Governance Addin Api

Governance Addin Api interface
