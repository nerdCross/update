# Governance Addin Mock

Governance Addin Mock is a skeleton program which is used as a mock to test the governance program with external addins
