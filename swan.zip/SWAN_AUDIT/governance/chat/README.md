# Governance chat

Governance chat is a program which allows voters to comment on proposals.
All comments are public and stored on chain.
